Traduction anglaise du MOD "Valkyrie Death Messages". Il s'agit d'une traduction du fichier de localisation qui ne sera utilisée que si vous avez le jeu en anglais.

En raison des caractéristiques de la langue, vous trouverez des phrases telles que "I have succumbed to smoke !" (J'ai succombé à la fumée) au lieu de "au fumée". En effet, la même phrase est utilisée pour "smoke, fire, poison" ou "frostbite", et il ne serait pas correct de dire "à la froid". Il en va de même pour des phrases telles que "J'ai été tué par un sanglier !", où, si l'on disait "Un sanglier", on rencontrerait des problèmes avec, par exemple, "Une tique". J'ai donc opté pour la forme la plus neutre, évitant ainsi des problèmes majeurs.


INSTALLATION :

Il suffit de copier le dossier dans "BeplnEx" en le mélangeant. Il ne doit rien remplacer.